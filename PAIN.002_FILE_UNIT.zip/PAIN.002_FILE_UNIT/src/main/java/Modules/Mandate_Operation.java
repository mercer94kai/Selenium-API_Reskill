package Modules;

public class Mandate_Operation {

	public void Mandate_operation(String UserID, String Legacy ) {
		
	}
	
	public void mandate_availability() {
		
	}
	
	public void mandate_processing() {
		
	}
	
	public void mandate_validation() {
		
	}
	
	public void mandate_conf_validation() {
		
	}
}
