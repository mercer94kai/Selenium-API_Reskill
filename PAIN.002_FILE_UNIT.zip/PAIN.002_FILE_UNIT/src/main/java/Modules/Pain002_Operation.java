package Modules;

public class Pain002_Operation {
	
	public void Pain002_Operation(String UserID, String Legacy, String Bank) {
		
	}
	
	public void Pain002_availability() {
		
	}
	
	public void Pain002_DataMapping_Vlidation() {
		
	}
	
	public void Pain002_processing() {
		
	}
	
	public void payment_status_validation() {
		
	}
	
	public void Accoount_Report_validation() {
		
	}
}
