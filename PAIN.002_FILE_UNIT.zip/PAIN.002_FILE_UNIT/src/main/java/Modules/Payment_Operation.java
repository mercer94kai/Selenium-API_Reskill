package Modules;

public class Payment_Operation {
	
	public void Payment_Operation(String UserID, String Legacy, String Bank) {
		
	}
	
	public void payment_availability() {
		
	}
	
	public void payment_processing() {
		
	}
	
	public void pain008_validation() {
		
	}
	
	public void payment_status_validation() {
		
	}

	public void payment_conf_validation() {
		
	}
}
